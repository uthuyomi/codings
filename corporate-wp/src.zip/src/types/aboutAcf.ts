export interface AboutAcf {
  about_us_img: string;
  about_us_heading: string;
  about_us_text: string;
  about_intro_heading: string;
  about_intro_text01: string;
  about_intro_text02: string;
  about_skill_heading: string;
}
export type AboutSkill = {
  id: number;
  acf: {
    about_skillset_heading: string;
    about_skillset_text: string;
  };
};
