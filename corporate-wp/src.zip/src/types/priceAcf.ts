export interface PriceAcf{ 
    pricepage_heading: string;
    pricepage_text: string;
}

export type TableRow = {
  title?: string;
  range?: string;
  duration: string;
  price: string;
  note?: string;
};

export type TableGroup = {
  heading: string;
  rows: TableRow[];
};

export type WPPricePage = {
  id: number;
  title: { rendered: string };
  acf: {
    price_acf_table_json: string;
  };
};