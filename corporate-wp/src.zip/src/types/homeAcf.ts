import { ExecFileSyncOptionsWithBufferEncoding } from "node:child_process";

export type HeroProps = {
  acf: {
    hero_heading?: string;
    hero_text?: string;
    hero_url?: string;
    hero_url_label?: string;
  };
};

export type ProfileProps = {
  acf: {
    profile_heading01: string;
    profile_img_url: string;
    profile_heading02: string;
    profile_text: string;
  };
};

export type ProfileSnsProps = {
  id: number,
  acf: {
    sns_img_thumbnail: string;
    sns_linkurl: string;
  }
}

export type ServiceProps = {
  service: {
    heading: string;
  };
};

export type ServiceContent = {
  id: string,
  acf: {
    service_item_thumbnail: string;
    service_item_title: string;
    service_item_text: string;
  }
}

export type SkillContent = {
  id: string;
  acf: {
    skill_item_thumbnail: String;
    skill_item_level_img: string;
    skill_item_text: string;
    skill_item_level_text: string;
  };
};