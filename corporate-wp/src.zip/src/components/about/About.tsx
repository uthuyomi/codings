import { useEffect, useState } from "react";
import style from "@/components/about/About.module.scss";
import Image from "next/image";
import { AboutAcf } from "@/types/aboutAcf";
import { fetchPage } from "@/lib/api";

const About = () => {
  const [acf, setAcf] = useState<AboutAcf | null>(null);

  useEffect(() => {
    //ページデータの取得
    fetchPage(127)
      .then((res) => setAcf(res.acf))
      .catch((err) => console.error("取得エラー:", err));
  }, []);

  if (!acf) {
    return <p>読み込み中...</p>;
  }

  return (
    <section className={style.about}>
      <div className={style.img}>
        <Image
          src={acf.about_us_img}
          alt={acf.about_us_img}
          width={100}
          height={100}
        />
      </div>
      <h2>{acf.about_us_heading}</h2>
      <p className="tagline">{acf.about_us_text}</p>
    </section>
  );
};

export default About;
