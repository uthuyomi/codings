import React from 'react'
import { useEffect, useState } from "react";
import style from "@/components/about/About.module.scss";
import { AboutAcf } from "@/types/aboutAcf";
import { fetchPage } from "@/lib/api";

const Intro = () => {
     const [acf, setAcf] = useState<AboutAcf | null>(null);
    
      useEffect(() => {
        //ページデータの取得
        fetchPage(127)
          .then((res) => setAcf(res.acf))
          .catch((err) => console.error("取得エラー:", err));
      }, []);
    
      if (!acf) {
        return <p>読み込み中...</p>;
      }
  return (
    <section className={style.intro}>
      <h2>{acf.about_intro_heading}</h2>
      <p>{acf.about_intro_text01}</p>
      <p>{acf.about_intro_text02}</p>
    </section>
  );
}

export default Intro