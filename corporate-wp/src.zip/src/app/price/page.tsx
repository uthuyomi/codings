// src/app/price/page.tsx

import ParticlesBackground from "@/components/common/particles/ParticlesBackground";
import { fetchPage } from "@/lib/api";
import Header from "@/components/common/header/Header";
import Hero from "@/components/home/Hero/Hero";
import Footer from "@/components/common/footer/Footer";
import PriceTable from "../../components/price/PriceContent";

type PageData = {
  acf: {
    hero_heading?: string;
    hero_text?: string;
    hero_url?: string;
    hero_url_label?: string;
  };
};

export default async function PricePage() {
  const page: PageData = await fetchPage(21);

  return (
    <>
      <Header />
      <ParticlesBackground />
      <Hero acf={page.acf} />
      <PriceTable />
      <Footer />
    </>
  );
}
