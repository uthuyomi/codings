import React from "react";
import { fetchPage } from "@/lib/api";
import ParticlesBackground from "@/components/common/particles/ParticlesBackground";
import Header from "@/components/common/header/Header";
import Hero from "@/components/home/Hero/Hero";
import Footer from "@/components/common/footer/Footer";
import style from "./About.module.scss";
import About from "../../components/about/About";
import Intro from "../../components/about/Intro";
import SkillSet from "../../components/about/SkillSet";

type PageData = {
  acf: {
    hero_heading?: string;
    hero_text?: string;
    hero_url?: string;
    hero_url_label?: string;
  };
};

export default async function AboutPage() {
  const page: PageData = await fetchPage(21);

  return (
    <>
      <Header />
      <ParticlesBackground />
      <Hero acf={page.acf} />
      <div className={style.page}>
        <About />
        <Intro />
        <SkillSet />
      </div>
      <Footer />
    </>
  );
}
